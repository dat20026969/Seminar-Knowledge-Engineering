from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Random import get_random_bytes
from Crypto.Hash import SHA256
from Crypto.Signature import pkcs1_15
import argparse
import os
import mimetypes

def is_valid_file(filepath):
    """Kiểm tra xem tệp có được hỗ trợ không"""
    mime_type, _ = mimetypes.guess_type(filepath)
    if mime_type is None:
        return False
    supported_types = ['text/', 'image/', 'application/', 'video/', 'audio/']
    return any(mime_type.startswith(t) for t in supported_types)

def generate_symmetric_key():
    """Tạo khóa đối xứng ngẫu nhiên"""
    return get_random_bytes(32)  # AES-256

def encrypt_symmetric_key(symmetric_key, public_key_path):
    """Mã hóa khóa đối xứng bằng khóa công khai của người nhận"""
    with open(public_key_path, 'rb') as f:
        public_key = RSA.import_key(f.read())
    cipher_rsa = PKCS1_OAEP.new(public_key)
    return cipher_rsa.encrypt(symmetric_key)

def encrypt_file(input_file, output_file, symmetric_key):
    """Mã hóa tệp bằng AES-GCM"""
    # Khởi tạo AES cipher với chế độ GCM
    cipher_aes = AES.new(symmetric_key, AES.MODE_GCM)
    
    # Đọc toàn bộ nội dung của tệp
    with open(input_file, 'rb') as f:
        data = f.read()
    
    # Mã hóa toàn bộ dữ liệu và lấy tag
    ciphertext, tag = cipher_aes.encrypt_and_digest(data)
    
    # Ghi nonce, tag và ciphertext vào file đầu ra
    with open(output_file, 'wb') as out_f:
        out_f.write(cipher_aes.nonce)  # Ghi nonce đầu tiên
        out_f.write(tag)               # Ghi tag
        out_f.write(ciphertext)        # Ghi dữ liệu đã mã hóa

    return data  # Trả về dữ liệu gốc để tạo chữ ký số

def create_signature(data, sender_private_key_path):
    """Tạo chữ ký số bằng khóa riêng của người gửi"""
    hash_obj = SHA256.new(data)
    with open(sender_private_key_path, 'rb') as f:
        private_key = RSA.import_key(f.read())
    signer = pkcs1_15.new(private_key)
    return signer.sign(hash_obj)

def main():
    parser = argparse.ArgumentParser(description='Mã hóa tệp và tạo chữ ký số')
    parser.add_argument('--receiver_pub_key', required=True, help='Tệp khóa công khai của người nhận')
    parser.add_argument('--input_file', required=True, help='Tệp cần mã hóa')
    parser.add_argument('--output_encrypted_file', required=True, help='Tệp đã mã hóa')
    parser.add_argument('--output_encrypted_symmetric_key', required=True, help='Tệp chứa khóa đối xứng đã mã hóa')
    parser.add_argument('--sender_private_key', required=True, help='Tệp khóa riêng của người gửi để ký')
    parser.add_argument('--output_signature', required=True, help='Tệp chứa chữ ký số')

    args = parser.parse_args()

    if not os.path.exists(args.input_file):
        print(f"Lỗi: Tệp '{args.input_file}' không tồn tại")
        return

    if not is_valid_file(args.input_file):
        print("Cảnh báo: Loại tệp có thể không được hỗ trợ")

    try:
        # Bước 1: Tạo khóa đối xứng và mã hóa nó bằng RSA
        symmetric_key = generate_symmetric_key()
        encrypted_symmetric_key = encrypt_symmetric_key(symmetric_key, args.receiver_pub_key)
        
        with open(args.output_encrypted_symmetric_key, 'wb') as f:
            f.write(encrypted_symmetric_key)

        # Bước 2: Mã hóa tệp và tạo chữ ký số
        original_data = encrypt_file(args.input_file, args.output_encrypted_file, symmetric_key)
        
        signature = create_signature(original_data, args.sender_private_key)
        with open(args.output_signature, 'wb') as f:
            f.write(signature)

        print("Mã hóa và ký thành công!")
    except Exception as e:
        print(f"Lỗi trong quá trình mã hóa: {str(e)}")

if __name__ == '__main__':
    main()
