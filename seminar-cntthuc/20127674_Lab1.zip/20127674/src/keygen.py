# keygen.py
from Crypto.PublicKey import RSA
import argparse

def generate_key_pair(bits=2048):
    """Tạo một cặp khóa RSA"""
    key = RSA.generate(bits)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

def save_key_to_file(key_data, filename):
    """Lưu khóa vào một tệp"""
    with open(filename, 'wb') as f:
        f.write(key_data)

def main():
    parser = argparse.ArgumentParser(description='Tạo cặp khóa RSA')
    parser.add_argument('--private_key', required=True, help='Tệp chứa khóa riêng')
    parser.add_argument('--public_key', required=True, help='Tệp chứa khóa công khai')
    parser.add_argument('--bits', type=int, default=2048, help='Kích thước khóa tính bằng bit')

    args = parser.parse_args()
    
    # Tạo cặp khóa
    private_key, public_key = generate_key_pair(args.bits)
    
    # Lưu khóa
    save_key_to_file(private_key, args.private_key)
    save_key_to_file(public_key, args.public_key)
    
    print("Cặp khóa đã được tạo và lưu thành công!")
    print(f"Khóa riêng: {args.private_key}")
    print(f"Khóa công khai: {args.public_key}")

if __name__ == '__main__':
    main()

