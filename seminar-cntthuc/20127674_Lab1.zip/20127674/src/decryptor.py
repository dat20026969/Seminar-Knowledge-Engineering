from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Hash import SHA256
from Crypto.Signature import pkcs1_15
import argparse
import os

def decrypt_symmetric_key(encrypted_key_file, private_key_file):
    """Giải mã khóa đối xứng bằng khóa riêng của người nhận"""
    with open(private_key_file, 'rb') as f:
        private_key = RSA.import_key(f.read())
    with open(encrypted_key_file, 'rb') as f:
        encrypted_key = f.read()
    cipher_rsa = PKCS1_OAEP.new(private_key)
    return cipher_rsa.decrypt(encrypted_key)

def decrypt_file(input_file, output_file, symmetric_key):
    """Giải mã tệp bằng AES-GCM"""
    with open(input_file, 'rb') as f:
        nonce = f.read(16)  # Đọc nonce (đã ghi từ lúc mã hóa)
        tag = f.read(16)    # Đọc tag
        ciphertext = f.read()  # Đọc phần còn lại là ciphertext

    # Khởi tạo AES cipher với nonce
    cipher_aes = AES.new(symmetric_key, AES.MODE_GCM, nonce=nonce)
    
    # Giải mã và xác thực tag
    data = cipher_aes.decrypt_and_verify(ciphertext, tag)
    
    # Ghi dữ liệu đã giải mã vào tệp đầu ra
    with open(output_file, 'wb') as out_f:
        out_f.write(data)

    return data  # Trả về dữ liệu để kiểm tra chữ ký số

def verify_signature(data, signature_file, sender_public_key_file):
    """Xác thực chữ ký số bằng khóa công khai của người gửi"""
    hash_obj = SHA256.new(data)
    with open(signature_file, 'rb') as f:
        signature = f.read()
    with open(sender_public_key_file, 'rb') as f:
        public_key = RSA.import_key(f.read())
    try:
        pkcs1_15.new(public_key).verify(hash_obj, signature)
        return True
    except (ValueError, TypeError):
        return False

def main():
    parser = argparse.ArgumentParser(description='Giải mã tệp và xác thực chữ ký số')
    parser.add_argument('--receiver_private_key', required=True, help='Tệp khóa riêng của người nhận')
    parser.add_argument('--encrypted_key', required=True, help='Tệp chứa khóa đối xứng đã mã hóa')
    parser.add_argument('--input_file', required=True, help='Tệp đã mã hóa')
    parser.add_argument('--output_decrypted_file', required=True, help='Tệp sau khi giải mã')
    parser.add_argument('--signature', required=True, help='Tệp chữ ký số')
    parser.add_argument('--sender_public_key', required=True, help='Tệp khóa công khai của người gửi')

    args = parser.parse_args()

    try:
        # Bước 1: Giải mã khóa đối xứng AES bằng khóa riêng của người nhận
        symmetric_key = decrypt_symmetric_key(args.encrypted_key, args.receiver_private_key)
        
        # Bước 2: Giải mã tệp bằng khóa AES đã giải mã
        decrypted_data = decrypt_file(args.input_file, args.output_decrypted_file, symmetric_key)
        print("Giải mã thành công!")

        # Bước 3: Xác thực chữ ký số
        if verify_signature(decrypted_data, args.signature, args.sender_public_key):
            print("FILE IS VALID")
        else:
            print("FILE IS INVALID")
    except Exception as e:
        print(f"Lỗi trong quá trình giải mã: {str(e)}")

if __name__ == '__main__':
    main()