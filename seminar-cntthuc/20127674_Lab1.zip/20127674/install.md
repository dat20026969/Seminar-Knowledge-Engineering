Trước hết thì Mở file 20127674.ipynb lên Google Colab.
Sau đó hãy upload các file code, (các) file cần thiết (.txt) và các file ảnh dưới định dạng .jpg, .jpeg và .png
Nếu muốn chạy được encrypt và decrypt thì phải rename tên tệp trong code ở Google Colab, như
!python3 encryptor.py --receiver_pub_key public.pem --input_file ''''''''''input.txt''''''''''''''' --output_encrypted_file encrypted.bin --output_encrypted_symmetric_key encrypted_key.bin --sender_private_key private.pem --output_signature signature.bin
Chỗ input.ixt nên rename trước khi sử dụng chúng.
